import java.util.ArrayList;
import java.util.ListIterator;

public class BasicDoubleLinkedList {
    public void addToEnd(String hello) {
    }

    public int getSize() {
    }

    public BasicDoubleLinkedListTest.Car getLast() {
    }

    public BasicDoubleLinkedListTest.Car getFirst() {
    }

    public void addToFront(String begin) {
    }

    public ArrayList<BasicDoubleLinkedListTest.Car> toArrayList() {
    }

    public ListIterator<String> iterator() {
    }

    public void remove(BasicDoubleLinkedListTest.Car a, BasicDoubleLinkedListTest.CarComparator comparatorCar) {
    }

    public String retrieveFirstElement() {
    }

    public String retrieveLastElement() {
    }
}
