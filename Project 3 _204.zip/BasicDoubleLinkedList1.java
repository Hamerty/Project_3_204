public class BasicDoubleLinkedList1 {
}
